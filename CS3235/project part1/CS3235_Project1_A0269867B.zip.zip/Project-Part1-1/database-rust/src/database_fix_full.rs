//==========Dont change these definitions==========================
const MAX_USERS: usize = 100;
const MAX_NAME_LEN: usize = 50;
const MAX_EMAIL_LEN: usize = 50;
const MAX_PASSWORD_LENGTH: usize = 100;
const INACTIVITY_THRESHOLD: i32 = 5;
const MAX_SESSION_TOKEN_LEN: usize = 32;

#[derive(Debug, Clone)]
pub struct UserStruct {
    pub password: [u8; MAX_PASSWORD_LENGTH],
    pub username: [u8; MAX_NAME_LEN],
    pub user_id: i32,
    pub email: [u8; MAX_EMAIL_LEN],
    pub inactivity_count: i32,
    pub is_active: i32,
    pub session_token: [u8; MAX_SESSION_TOKEN_LEN],
}


#[derive(Debug)]
pub struct UserDatabase {
    pub users: [Option<Box<UserStruct>>; MAX_USERS],
    pub count: i32,
    pub capacity: i32,
}
//====================================End of Definitions=======================================
use std::str;
use std::cmp::min;

// Helper function.
// Takes in a mutable reference to an array, and returns a String
pub fn array_to_string<const N: usize>(bytes: &[u8; N]) -> String {
    match str::from_utf8(bytes) {
        Ok(s) => s.trim_end_matches('\x00').to_string(),
        Err(e) => format!("Error: {}", e),
    }
}

fn init_database() -> Box<UserDatabase> {
  let db = UserDatabase {
    users: std::array::from_fn(|_| None),
    count: 0,
    capacity: MAX_USERS as i32,
  };

  Box::new(db)
}

fn add_user(db: &mut UserDatabase, user: Box<UserStruct>) {
  let mut user_mut : Box<UserStruct> = user;
  if (db.count as usize)< MAX_USERS as usize{
    

    user_mut.user_id = db.count;
    db.users[db.count as usize] = Some(user_mut);
    db.count +=1;
  }
}

fn free_user(user : &mut UserStruct){
    user.is_active=0;
}

fn print_database(db: &UserDatabase) {
  for i in 0..db.count {
    // 'if let' is a pattern matching expression
    //
    // Here, it tries to match &db.users[i] (a reference to an Option<Box<UserStruct>>)
    // against the pattern Some(user).
    //
    // If the slot contains Some, the block runs and'user' is a reference to the Box<UserStruct>.
    // If it's None, the block is skipped.

    if let Some(user) = &db.users[i as usize] {
      println!(
        "User: {}, ID: {}, Email: {}, Inactivity: {}, Password: {}",
        array_to_string(&user.username),
        user.user_id,
        array_to_string(&user.email),
        user.inactivity_count,
        array_to_string(&user.password),
      );
    }
  }
}

// dest: Want to copy values from src into array, but caller keeps ownership of array.
// So pass in a mutable reference to the array.
fn copy_string(dest : &mut [u8], src : &str, n : usize) {
    let bytes = src.as_bytes();

    let max = dest.len() -1;
    let copyLen = min(n, min(bytes.len(), max));

    for i in 0..copyLen {
        dest[i] = bytes[i];
    }
    dest[n] = 0; //null terminate
}

// Returns UserStruct, caller takes ownership of UserStruct.
fn create_user(username : &str, email : &str, user_id : i32, password : &str) -> Box<UserStruct> {
    let mut user = UserStruct {
        password: [0; MAX_PASSWORD_LENGTH],
        username: [0; MAX_NAME_LEN],
        user_id,
        email: [0; MAX_EMAIL_LEN],
        inactivity_count: 0,
        is_active : 1,
        session_token: [0; MAX_SESSION_TOKEN_LEN],
    };

    copy_string(&mut user.password, password, password.len());
    copy_string(&mut user.username, username, username.len());
    copy_string(&mut user.email, email, email.len());
    Box::new(user) // Return the user
}

//fn find_user_by_id( db : &mut UserDatabase , user_id : i32) -> Option<&mut UserStruct> {
//    for i in 0..db.count {
//        if let Some(user) = db.users[i as usize].as_mut() { 
//            if user.user_id == user_id {
//                return Some(&mut **user);
//            }
//        }
//    }
//    return None;
//}


fn find_user_by_id(db: &mut UserDatabase, user_id: i32) -> Option<&mut UserStruct> {
    // .iter_mut() to bypass multiple borrowing issues when iterating via for i in 0..db.count
    for user_option in db.users.iter_mut() {
        // db.users is [Option<Box<UserStruct>>; MAX_USERS]
        // iter_mut() produces an iterator over this

        // user_option has type: &mut Option<Box<UserStruct>>
        if let Some(user) = user_option {
            // user is now &mut <Box<UserStruct>>

            if user.user_id == user_id {
                
                // First dereference: get Box<UserStruct>
                // Second dereference: get UserStruct
                // Add in &mut: get &mut UserStruct
                // Add in Some(): get Option<&mut UserStruct>
                return Some(&mut **user); 

            }
        }
    }
    None
}


fn cleanup_database(db : &mut UserDatabase) {
    for i in 0..db.count {
        db.users[i as usize] = None;
    }
}

fn update_database_daily(db : &mut UserDatabase) {
    for i in 0..db.count {
        if let Some(user) = &mut db.users[i as usize] { //mutable borrow
            if user.inactivity_count > INACTIVITY_THRESHOLD {
                db.users[i as usize] = None;
                //free_user(user);
            } else {
                user.inactivity_count +=1 ;
            }
        }
    }
}

fn update_username (db: &mut UserDatabase, username : &str, new_username : &str) {
    if let Some(user) = find_user_by_username(db, username) {
        // user is &mut UserStruct

        if new_username.len() >= 50 {
            let truncated: String = new_username.chars().take(49).collect();
            copy_string(&mut user.username, &truncated, truncated.len());
        } else {
           copy_string(&mut user.username, new_username, new_username.len());
        }
    }
}

fn user_login (db: &mut UserDatabase, username : &str) {
    if let Some(user) = find_user_by_username(db, username) {
        //user is &mut UserStruct
        user.inactivity_count = 0;
    }
}

// Cannot return an Option<&[u8]>.
// Cannot return a mutable reference into the user struct, since the user's reference is also
// borrowed
fn get_password(db : &mut UserDatabase, username: &str) -> Option<String> {
    if let Some(user) = find_user_by_username(db, username) {
        //user is &mut UserStruct
        Some(array_to_string(&user.password))
    } else {
        None
    }
}


fn update_password(db : &mut UserDatabase, username: &str , password: &str) {
    if let Some(user) = find_user_by_username(db, username) {
        //user is &mut UserStruct
        copy_string(&mut user.password, password, password.len());
    }  
}

fn print_user(db : &mut UserDatabase, username : &str) {
    if let Some(user) = find_user_by_username(db, username) {
        //user is a &mut UserStruct
        println!("User[{}] {}: Email: {}, Inactivity: {}, Password: {} \n",
                 user.user_id,
                 array_to_string(&user.username),
                 array_to_string(&user.email),
                 user.inactivity_count,
                 array_to_string(&user.password)
                 );
    } 

}

fn find_user_by_username<'a> (db: &'a mut UserDatabase, username : &str) -> Option<&'a mut UserStruct> {
    for user_option in db.users.iter_mut() {
        if let Some(user) = user_option{
        
            if std::str::from_utf8(&user.username)
                .unwrap_or("")
                .trim_end_matches(char::from(0)) == username
                {
                    return Some(&mut **user);
                }
        }
    } None
}


fn main(){
    let args: Vec<String> = std::env::args().collect();
    // args[0] is program name, args[1] is first argument...
    
    if args.len() <2 {
        println!("Usage: {} <payload_type>\n 0. OUT_OF_BOUNDS_PAYLOAD\n 1. DOUBLE_FREE_PAYLOAD\n 2. USE_AFTER_FREE_PAYLOAD", args[0]);
        std::process::exit(1);
    }

    let iter: u32 = args[1].parse().expect("Error"); // parse converts string to int

    let mut db : Box<UserDatabase> = init_database();

    let mallory : Box<UserStruct> = create_user("Mallory", "mallory@nus.edu.sg", 0, "malloryisnotevil");
    add_user(&mut db, mallory);
    let alice : Box<UserStruct> = create_user("Alice", "alice@nus.edu.sg", 1, "aliceinthewonderland");
    add_user(&mut db, alice);
    let bob : Box<UserStruct> = create_user("Bob", "bob@nus.edu.sg", 2, "bobthebuilder");
    add_user(&mut db, bob);
    let eve : Box<UserStruct> = create_user("Eve", "eve@nus.edu.sg", 3, "eve4ever");
    add_user(&mut db, eve);

    match iter {
        0 => {
            //&mut UserDatabase, username : &str, new_username : &str
            update_username(&mut db, "Mallory", "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC");
        },
        1 => {
            for i in 0..=INACTIVITY_THRESHOLD+2 {
                println!("----------------------Day {}: User login and database update-----------------------\n", i + 1);
                user_login(&mut db, "Alice");
                user_login(&mut db, "Bob");
                update_database_daily(&mut db);
                println!("\n");
            }
        },
        2 => {
            println!("--------------Starting a sprint of the database update and user login-------------\n");
            for i in 0..=INACTIVITY_THRESHOLD+1 {
                user_login(&mut db, "Alice");
                user_login(&mut db, "Bob");
                update_database_daily(&mut db);
            }

            println!("--------------Database update and user login sprint finished----------------------\n");
            let charlie : Box<UserStruct> = create_user("Charlie", "charlie@nus.edu.sg", 3, "charlieandthechocolatefactory");
            add_user(&mut db, charlie);
            let bruce : Box<UserStruct> = create_user("Bruce", "bruce@nus.edu.sg", 4, "iambatman");
            add_user(&mut db, bruce);
            let joker : Box<UserStruct> = create_user("Joker", "joker@nus.edu.sg", 5, "whysoserious");
            add_user(&mut db, joker);
            println!("Mallory wants to login and update her password \n");
            update_password(&mut db, "Mallory", "Malloryiswatchingyou");
            
            println!("Eve wants to get her password => \n");
            if let Some(password) = get_password(&mut db, "Eve") {
                println!("Eve's password is: {}\n", password);
            }

        },
        _ => {
        }
    }

    println!("==============================Final Database State:===========================================\n");
    print_database(&db);
    println!("==============================================================================================\n");


}

